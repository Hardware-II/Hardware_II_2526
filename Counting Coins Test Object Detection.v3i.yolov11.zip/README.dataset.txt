# Counting Coins Test Object Detection > 2026-01-26 12:33pm
https://universe.roboflow.com/dklopotek/counting-coins-test-object-detection-v9inq

Provided by a Roboflow user
License: CC BY 4.0

