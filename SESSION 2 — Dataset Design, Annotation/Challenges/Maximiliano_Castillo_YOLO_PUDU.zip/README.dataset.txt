# pudu2 > pudu_master
https://universe.roboflow.com/ccvi/pudu2

Provided by a Roboflow user
License: Public Domain

