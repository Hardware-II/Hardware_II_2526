# 20262601_HardwareII > 2026-02-02 4:01pm
https://universe.roboflow.com/hardwareiiroboflow/20262601_hardwareii

Provided by a Roboflow user
License: CC BY 4.0

