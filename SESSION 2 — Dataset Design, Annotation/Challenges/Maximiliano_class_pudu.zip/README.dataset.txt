# pudu2 > 2026-02-02 4:54pm
https://universe.roboflow.com/ccvi/pudu2

Provided by a Roboflow user
License: Public Domain

