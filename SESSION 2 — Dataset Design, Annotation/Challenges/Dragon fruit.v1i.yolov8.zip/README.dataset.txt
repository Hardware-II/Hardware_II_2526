# Dragon fruit > 2026-01-26 12:49pm
https://universe.roboflow.com/xiomaraalcivar/dragon-fruit-nm5io

Provided by a Roboflow user
License: CC BY 4.0

