# horse > 2026-02-06 7:19pm
https://universe.roboflow.com/hardware-biea3/horse-6gpg3

Provided by a Roboflow user
License: CC BY 4.0

