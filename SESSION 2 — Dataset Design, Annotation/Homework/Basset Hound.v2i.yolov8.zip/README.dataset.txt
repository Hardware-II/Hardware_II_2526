# Basset Hound > 2026-02-02 5:14pm
https://universe.roboflow.com/xiomaraalcivar/basset-hound

Provided by a Roboflow user
License: CC BY 4.0

