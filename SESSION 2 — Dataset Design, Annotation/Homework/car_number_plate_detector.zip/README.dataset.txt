# car number plates > 2026-02-02 10:20am
https://universe.roboflow.com/jineshjainhardware/car-number-plates-cd50f

Provided by a Roboflow user
License: CC BY 4.0

