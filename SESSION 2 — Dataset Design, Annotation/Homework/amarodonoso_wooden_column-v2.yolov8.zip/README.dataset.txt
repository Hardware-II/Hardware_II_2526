# Wooden Column Detection > wooden_column-v2
https://universe.roboflow.com/hardwareii/wooden-column-detection

Provided by a Roboflow user
License: CC BY 4.0

