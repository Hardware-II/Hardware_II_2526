# Windows Detector > 2026-02-03 1:01pm
https://universe.roboflow.com/hardwareiiroboflow/windows-detector

Provided by a Roboflow user
License: CC BY 4.0

