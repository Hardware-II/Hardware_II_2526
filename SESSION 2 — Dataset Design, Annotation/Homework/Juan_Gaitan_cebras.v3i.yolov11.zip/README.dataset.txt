# cebras > 2026-01-28 12:37pm
https://universe.roboflow.com/juan-elouk/cebras

Provided by a Roboflow user
License: CC BY 4.0

