from ultralytics import YOLO
from pathlib import Path

# Ruta a tu data.yaml de Roboflow
DATA_YAML = Path("zorros-yolo.v1i.yolov8/data.yaml")

# Carga modelo base YOLOv8 (nano = rápido, puedes usar s, m, l si tienes GPU)
model = YOLO("yolov8n.pt")

# Entrenamiento
model.train(
    data=str(DATA_YAML),
    epochs=50,
    imgsz=640,
    batch=16,
    name="fox_yolov8"
)
