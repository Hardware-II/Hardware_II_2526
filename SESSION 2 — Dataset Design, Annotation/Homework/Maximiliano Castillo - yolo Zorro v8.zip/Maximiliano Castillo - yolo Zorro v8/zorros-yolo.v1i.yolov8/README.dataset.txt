# zorros-yolo > 2026-02-01 7:37pm
https://universe.roboflow.com/ccvi/zorros-yolo

Provided by a Roboflow user
License: CC BY 4.0

