# 🦊 Homework — YOLOv8 Fox Detection  
**Author:** Maximiliano Castillo Milla  

## Objective  
Train a YOLOv8 model to detect **foxes (zorro)** using ~**200 images** at **256×256 px** resolution.

## Tools  
- YOLOv8 (Ultralytics)  
- Python  
- Roboflow  
- OpenCV  