# zorros-yolo > 2026-02-02 4:56pm
https://universe.roboflow.com/ccvi/zorros-yolo

Provided by a Roboflow user
License: CC BY 4.0

